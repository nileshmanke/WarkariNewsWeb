import React from 'react'

const Loading = () => {
  return (
    <div>

        <img src='src/components/Eclipse-1s-170px.gif' alt='Loading..'/>
    </div>
  )
}

export default Loading